package Deck_of_Cards;

public enum Valore {

	ASSO,
	DUE,
	TRE,
	QUATTRO,
	CINQUE,
	SEI,
	SETTE,
	OTTO,
	NOVE,
	DIECI,
	JACK,
	QUEEN,
	KAPPA;
}
