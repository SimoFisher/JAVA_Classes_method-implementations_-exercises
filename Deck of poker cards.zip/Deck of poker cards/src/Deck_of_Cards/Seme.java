package Deck_of_Cards;

public enum Seme {
	
	QUADRI,CUORI,PIQQE,FIORI;

}
