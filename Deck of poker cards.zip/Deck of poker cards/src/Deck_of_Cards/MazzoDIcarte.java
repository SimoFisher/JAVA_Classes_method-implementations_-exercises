package Deck_of_Cards;

import java.util.Random;

public class MazzoDIcarte {
/*
	
Exercise: shuffle and deal a deck of playing cards, such as 52-card poker
	• Design a Card class that represents a single
	playing card (with suit and rank)
	– The class must return its representation upon request
	in the form of a string
	• Next, design a DeckOfCards class to represent
	an entire deck of 52 cards
	• The class must implement the following methods:
	– shuffle the deck of cards
	– deal the next card
	• Finally, design a test class that creates a deck,
	you shuffle the cards and deal out cards until you run out
	of the deck
*/  

/* Classes analysis:
	without UML, as you can see we have four classes, two of which are Enumerations (one for card suits and one for values).
	In this case the enumerations lend themselves well to the purpose since they are constants that do not change over time.
	The Card class, on the other hand, has a constructor with parameters of the Enum type Seed/Value and Setter/Getter methods
	and a toString to have a representation in the form of a string. The Deck of Cards class, which is responsible for creating
	the deck of cards and distribute it until it runs out of cards, under the main method to test the Class
*/	
	private Card mazzo[];
	public MazzoDIcarte()
	// make the constructor with no arguments
	{ // let the constructor iterate through the enums directly
		this.mazzo=new Card[52];
		int i=0;
		for(Valore valore:Valore.values())
			for(Seme seme: Seme.values())
		 // double for loop that iterates over suit and card values
			{
				mazzo[i]=new Card(seme,valore);
				i++;
			}
			
		
		
	}
	
	public void mischia() {
	    
	    Random random=new Random();
		for(int t=0;t<mazzo.length;t++)
		{   int randomSwap=random.nextInt(mazzo.length);
			Card temp=mazzo[randomSwap];
			mazzo[randomSwap]=mazzo[t];
			mazzo[t]= temp;
			// upcasting 
			
			System.out.println(mazzo[t]);
		}
		
	}
	public Card nextCarta(int i)
	{   
		return mazzo[i++];
	}
	
	
	
	public static void main(String[]args)
	{
		MazzoDIcarte MZ=new MazzoDIcarte();
		MZ.mischia();
		System.out.println();
		for(int i=0;i<51;i++)
		{
			System.out.println(MZ.nextCarta(i));
		}
		
	}
	
}
