package Deck_of_Cards;

public class Card {
	
	private Seme seme;
	private Valore valore;
	public Card(Seme seme,Valore valore)
	// costructor passed in two enums
	{
		this.seme=seme;
		this.valore=valore;
		
	}
	public Seme getSeme() {
		return seme;
	}
	public void setSeme(Seme seme) {
		this.seme = seme;
	}
	public Valore getValore() {
		return valore;
	}
	public void setValore(Valore valore) {
		this.valore = valore;
	}
	@Override
	public String toString() {
		return valore+" DI "+seme;
	}
	

	
	
	
}
