package Webinar_7_LinkedList;

import java.util.Iterator;

public class LinkedList implements Iterable<Integer>{
	
/*
 * 
Inner Class Element
the constructor is not present
 An empty LinkedList is created

*/

private Element head;// reference to Element, type Element 
private Element last;
public void add(Integer i)
{
	if(head==null)
		{
		
		head=new Element(i);
		head=last;// if the head is null, I insert an element
		          //which is also the last node being the only one
		}
	else
	{
		
		last.setSuccessivo(new Element(i)); // create a new element object, passing 
		                                   // it an Integer as an argument 
		last=last.getSuccessivo();
		last=head;	
	}
		
}

@Override // @Override for the method iterator() implemented by Iterable
public Iterator<Integer>iterator()
{
	return new Iterator<Integer>(){ // return a new Iterator of Integers
	    
		private Element curr=head;
		@Override
		public boolean hasNext() {return curr==null?false:true; }
		@Override
		public Integer next(){
			if (hasNext()) // if true 
			{
				Integer val=curr.getValore();
				curr=curr.getSuccessivo();
				return val; // return the last value, when curr==null
				
			}
			return null;
		}
	};
}


public static class Element{ // I need to create a class of type Element to represent nodes,with integers
	private Integer Value;
	private Element next_e; 
	public Element(Integer Value){this.setValore(Value);}
	//constructor that takes an integer as a value and invokes the setter of value 
	public Integer getValore(){return Value;}
	public void setValore(Integer Value){this.Value=Value;}
	public Element getSuccessivo(){return next_e;}
	public void setSuccessivo(Element e) {this.next_e=e;}
}




}
